import ChannelList from './ChannelList';

export default ChannelList;