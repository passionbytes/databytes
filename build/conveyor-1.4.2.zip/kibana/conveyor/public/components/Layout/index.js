import ContentBody from './ContentBody/ContentBody';
import ContentHeader from './ContentHeader/ContentHeader';

export {
  ContentBody,
  ContentHeader
};